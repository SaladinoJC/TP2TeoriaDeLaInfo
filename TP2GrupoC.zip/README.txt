Para ejecutar el script de python hay que tener python instalado en la pc y desde terminal:
python Tp2.py "nombredelsample.txt" "nombre del archivo de salida opcional"  N (opcional)
